# REGRAS DO PROJETO - BOT WHATSAPP

## REGRA #1 - NÃO MODIFICAR LAYOUT
**NUNCA modificar o layout/estrutura existente quando adicionar nova funcionalidade.**

- ✅ Só ADICIONAR código novo
- ❌ NÃO reescrever arquivos inteiros
- ❌ NÃO mudar estrutura que está funcionando
- ❌ NÃO mexer em CSS/HTML existente

## REGRA #2 - MANTER VERSÕES ESTÁVEIS
**Se está funcionando, NÃO MEXER.**

- Versão 7.2 estava estável
- Só adicionar features pedidas
- Preservar lógica que funciona

## REGRA #3 - PERGUNTAR ANTES DE MUDAR
**Se tiver dúvida, perguntar ao usuário.**

- Não assumir o que o usuário quer
- Confirmar antes de mudar algo existente

## HISTÓRICO DE VERSÕES

| Versão | Status | Observação |
|--------|--------|------------|
| 7.2 | ✅ ESTÁVEL | Funcionando bem |
| 7.3 | ✅ ESTÁVEL | Adicionado blacklist (numerosIgnorados) |
| 7.4 | ⚠️ | Tentativa de favoritos |
| 7.5 | ❌ MUDOU DEMAIS | Quebrou coisas que funcionavam |

## FUNÇÕES CONFIRMADAS FUNCIONANDO (7.2):

1. Pausa automática quando entra na conversa
2. Comandos !bot on/off/status
3. IA com dados cadastrados
4. Menu interativo
5. Painel web

## NUNCA MEXER:

1. **Prompt do Sistema (IA)** - deixar como está na 7.2
2. **Dados da empresa** - nunca apagar/modificar dados cadastrados
3. **CSS/Layout** - não mudar visual que está funcionando
4. **Lógica de pausa** - não mexer se está funcionando

## PARA PRÓXIMAS ATUALIZAÇÕES:

1. Ler este arquivo antes de modificar
2. Só adicionar, não reescrever
3. Testar antes de commitar
4. Manter backward compatibility
5. NÃO mexer no prompt da IA
6. NÃO mexer nos dados da empresa
