/**
 * ============================================
 * BOT WHATSAPP PROFISSIONAL v7.5
 * ============================================
 * 
 * v7.5 - FAVORITOS NA LISTA DE PAUSADOS:
 * - Botão ⭐ na lista de pausados
 * - Números favoritos são ignorados permanentemente
 * - Config salva favoritos automaticamente
 * 
 * RECURSOS:
 * - IA só responde com dados do cadastro
 * - NUNCA inventa valores ou informações
 * - Auto-pausa quando você responde cliente
 * - Comandos !bot on/off/status
 */

const express = require("express");
const http = require("http");
const { Server } = require("socket.io");
const path = require("path");
const fs = require("fs");
const QRCode = require("qrcode");
const { Client, LocalAuth } = require("whatsapp-web.js");
const OpenAI = require("openai");

// =====================================
// CONFIGURAÇÃO
// =====================================
const PORT = 3000;
const CONFIG_FILE = path.join(__dirname, "config.json");
const BASE_CONHECIMENTO_FILE = path.join(__dirname, "base-conhecimento.json");

let groqClient = null;
let whatsappClient = null;
let whatsappConectado = false;
let io = null;

let baseConhecimento = null;
const clientesPausados = new Map();
const historicoConversas = new Map();
const sessoesAtendimento = new Map();
const mensagensEnviadasPeloBot = new Map();
const MAX_HISTORICO = 5;

// Números favoritos (bot ignora permanentemente)
let numerosFavoritos = [];

function gerarProtocolo() {
  return Date.now().toString(36).toUpperCase() + Math.random().toString(36).substring(2, 6).toUpperCase();
}

// =====================================
// CARREGAR ARQUIVOS
// =====================================

function loadConfig() {
  try { 
    if (fs.existsSync(CONFIG_FILE)) {
      const cfg = JSON.parse(fs.readFileSync(CONFIG_FILE, "utf8"));
      numerosFavoritos = cfg.numerosFavoritos || [];
      return cfg;
    }
  } catch (e) {}
  return { 
    groqApiKey: "", 
    useAI: true, 
    model: "llama-3.1-8b-instant", 
    numeroAtendente: "5549998418446",
    numerosFavoritos: []
  };
}

function saveConfig(config) { fs.writeFileSync(CONFIG_FILE, JSON.stringify(config, null, 2), "utf8"); }

function carregarBaseConhecimento() {
  try { if (fs.existsSync(BASE_CONHECIMENTO_FILE)) { baseConhecimento = JSON.parse(fs.readFileSync(BASE_CONHECIMENTO_FILE, "utf8")); console.log("Base carregada!"); return baseConhecimento; } } catch (e) {}
  return null;
}

function salvarBaseConhecimento(base) {
  try { fs.writeFileSync(BASE_CONHECIMENTO_FILE, JSON.stringify(base, null, 2), "utf8"); baseConhecimento = base; return true; } catch (e) { return false; }
}

let config = loadConfig();
carregarBaseConhecimento();

if (config.groqApiKey?.trim()) {
  groqClient = new OpenAI({ apiKey: config.groqApiKey, baseURL: "https://api.groq.com/openai/v1" });
}

// =====================================
// BUSCA NA BASE DE CONHECIMENTO
// =====================================

function normalizar(texto) {
  return texto.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/[^a-z0-9\s]/g, " ").replace(/\s+/g, " ").trim();
}

function buscarNaBase(texto) {
  if (!baseConhecimento) return null;
  
  const textoNorm = normalizar(texto);
  
  // Buscar nas categorias
  for (const [id, cat] of Object.entries(baseConhecimento.categorias || {})) {
    const palavras = cat.palavrasChave || [];
    for (const p of palavras) {
      if (textoNorm.includes(normalizar(p))) {
        // Verificar subcategorias
        if (cat.subcategorias) {
          for (const [subId, sub] of Object.entries(cat.subcategorias)) {
            for (const sp of (sub.palavrasChave || [])) {
              if (textoNorm.includes(normalizar(sp))) {
                return sub.resposta;
              }
            }
          }
        }
        return cat.respostaPadrao;
      }
    }
  }
  
  // Buscar respostas rápidas
  for (const r of (baseConhecimento.respostasRapidas || [])) {
    if (textoNorm.includes(normalizar(r.pergunta))) {
      return r.resposta;
    }
  }
  
  return null;
}

// =====================================
// HISTORICO
// =====================================

function adicionarHistorico(tel, tipo, msg) {
  if (!historicoConversas.has(tel)) historicoConversas.set(tel, []);
  const h = historicoConversas.get(tel);
  h.push({ tipo, msg, ts: Date.now() });
  if (h.length > MAX_HISTORICO) h.shift();
}

// =====================================
// IA COM REGRAS RIGIDAS
// =====================================

async function respostaPorIA(texto, telefone) {
  if (!groqClient || !config.groqApiKey) return null;
  
  try {
    const emp = baseConhecimento?.empresa || {};
    const cats = baseConhecimento?.categorias || {};
    const extras = baseConhecimento?.informacoesAdicionais || [];
    
    // Prompt SUPER RIGIDO
    const promptRigido = `Voce e o BOT de atendimento da empresa "${emp.nome || "Assistencia Tecnica"}".

REGRAS OBRIGATORIAS - NUNCA VIOLAR:

1. VOCE E UM ROBO, nao uma pessoa. Nao tenha emocoes, nao seja empatico, nao se desculpe.
2. SO RESPONDA com as informacoes abaixo. Se nao tiver a informacao, diga: "Nao tenho essa informacao. Digite *menu* para ver as opcoes ou *atendente* para falar com uma pessoa."
3. NUNCA invente valores, precos, prazos ou informacoes que nao estao escritas abaixo.
4. NUNCA faca comentarios pessoais, nao pergunte sobre saude, nao se preocupe com o cliente.
5. Se o cliente perguntar algo fora do escopo (saude, pessoal, etc), responda: "So atendo duvidas sobre nossos servicos tecnicos. Digite *menu* para ver as opcoes."
6. Respostas curtas, diretas, sem emojis excessivos.
7. Nao use linguagem afetiva (querido, amigo, etc).

=== INFORMACOES DA EMPRESA ===
Nome: ${emp.nome || "Nao informado"}
Telefone: ${emp.telefone || "Nao informado"}
WhatsApp: ${emp.whatsapp || "Nao informado"}
Endereco: ${emp.endereco || "Nao informado"}
Cidade: ${emp.cidade || "Nao informado"}

=== HORARIO ===
${emp.horarioAtendimento?.semana || ""}
${emp.horarioAtendimento?.sabado || ""}
Domingo: ${emp.horarioAtendimento?.domingo || "Fechado"}

=== SERVICOS ===
${(emp.servicos || []).join("\n")}

=== VALORES (SO ESTES!) ===
- Troca de tela celular: a partir de R$ 150
- Bateria celular: a partir de R$ 80
- Formatacao notebook: a partir de R$ 80
- Orcamento: GRATUITO
Para outros valores: "Traga o aparelho para orcamento gratuito."

=== GARANTIA ===
${emp.garantia || "90 dias"}

=== PAGAMENTO ===
${(emp.formasPagamento || []).join(", ")}

=== INFORMACOES EXTRAS ===
${extras.map(e => `${e.titulo}: ${e.conteudo}`).join("\n")}

=== RESPOSTAS PRONTAS ===
${Object.values(cats).map(c => `${c.titulo}: ${c.respostaPadrao}`).join("\n\n")}

PERGUNTA DO CLIENTE: ${texto}

Responda seguindo TODAS as regras acima:`;

    const completion = await groqClient.chat.completions.create({
      model: config.model || "llama-3.1-8b-instant",
      messages: [{ role: "user", content: promptRigido }],
      max_tokens: 300,
      temperature: 0.1, // MUITO BAIXO - menos criatividade
    });
    
    return completion.choices?.[0]?.message?.content?.trim() || null;
  } catch (e) {
    console.error("Erro IA:", e.message);
    return null;
  }
}

// =====================================
// EXPRESS
// =====================================
const app = express();
const server = http.createServer(app);
io = new Server(server);

app.use(express.json());
app.use(express.static(path.join(__dirname, "public")));

app.get("/api/config", (req, res) => { const s = { ...config }; if (s.groqApiKey) s.groqApiKey = s.groqApiKey.substring(0, 8) + "***"; res.json(s); });
app.get("/api/config/full", (req, res) => res.json(config));
app.post("/api/config", (req, res) => { config = { ...config, ...req.body }; saveConfig(config); if (config.groqApiKey?.trim()) groqClient = new OpenAI({ apiKey: config.groqApiKey, baseURL: "https://api.groq.com/openai/v1" }); res.json({ ok: true }); });
app.get("/api/base-conhecimento", (req, res) => res.json(baseConhecimento || {}));
app.post("/api/base-conhecimento", (req, res) => { salvarBaseConhecimento(req.body); res.json({ ok: true }); });
app.post("/api/empresa", (req, res) => { if (!baseConhecimento) baseConhecimento = { empresa: {} }; baseConhecimento.empresa = { ...baseConhecimento.empresa, ...req.body }; salvarBaseConhecimento(baseConhecimento); res.json({ ok: true }); });
app.post("/api/informacao", (req, res) => { if (!baseConhecimento) baseConhecimento = { informacoesAdicionais: [] }; if (!baseConhecimento.informacoesAdicionais) baseConhecimento.informacoesAdicionais = []; const idx = baseConhecimento.informacoesAdicionais.findIndex(i => i.titulo === req.body.titulo); if (idx >= 0) baseConhecimento.informacoesAdicionais[idx] = req.body; else baseConhecimento.informacoesAdicionais.push(req.body); salvarBaseConhecimento(baseConhecimento); res.json({ ok: true }); });
app.get("/api/clientes-pausados", (req, res) => { const l = []; clientesPausados.forEach((v, k) => l.push({ telefone: k, ...v })); res.json(l); });
app.post("/api/bot/cliente", (req, res) => { const { telefone, pausar } = req.body; if (!telefone) return res.status(400).json({ erro: "Telefone obrigatorio" }); if (pausar) clientesPausados.set(telefone, { pausado: true }); else clientesPausados.delete(telefone); res.json({ ok: true }); });

// Favoritos (números que o bot ignora permanentemente)
app.get("/api/favoritos", (req, res) => {
  res.json(numerosFavoritos);
});

app.post("/api/favoritos", (req, res) => {
  const { telefone } = req.body;
  if (!telefone) return res.status(400).json({ erro: "Telefone obrigatório" });
  
  // Normalizar telefone
  const tel = telefone.replace(/[@\.]/g, "").slice(0, 15);
  if (!numerosFavoritos.includes(tel)) {
    numerosFavoritos.push(tel);
    config.numerosFavoritos = numerosFavoritos;
    saveConfig(config);
  }
  // Remover dos pausados se estiver lá
  clientesPausados.delete(telefone);
  res.json({ ok: true, favoritos: numerosFavoritos });
});

app.delete("/api/favoritos", (req, res) => {
  const { telefone } = req.body;
  const tel = telefone.replace(/[@\.]/g, "").slice(0, 15);
  numerosFavoritos = numerosFavoritos.filter(n => n !== tel && !n.includes(tel));
  config.numerosFavoritos = numerosFavoritos;
  saveConfig(config);
  res.json({ ok: true, favoritos: numerosFavoritos });
});

app.post("/api/whatsapp/disconnect", async (req, res) => { if (whatsappClient) { whatsappConectado = false; try { await whatsappClient.destroy(); } catch (e) {} whatsappClient = null; } res.json({ ok: true }); });
app.post("/api/whatsapp/restart", async (req, res) => { if (whatsappClient) { try { await whatsappClient.destroy(); } catch (e) {} whatsappClient = null; } whatsappConectado = false; if (req.query.limpar === "1") { const a = path.join(__dirname, ".wwebjs_auth"); if (fs.existsSync(a)) fs.rmSync(a, { recursive: true }); } io.emit("qr", "loading"); initWhatsApp(true); res.json({ ok: true }); });
app.get("/", (req, res) => res.sendFile(path.join(__dirname, "public", "index.html")));

// =====================================
// MENU
// =====================================

function getMenuTexto(protocolo) {
  return `Ola! Bem-vindo(a)!

Protocolo: ${protocolo}

*Digite o numero:*

1 - Servicos
2 - Horarios
3 - Valores
4 - Localizacao
5 - Pagamento
6 - Garantia
7 - Falar com Atendente

Ou digite sua pergunta.`;
}

// =====================================
// WHATSAPP
// =====================================
function initWhatsApp(force = false) {
  if (whatsappClient && !force) return;
  if (whatsappClient && force) whatsappClient = null;

  whatsappClient = new Client({
    authStrategy: new LocalAuth({ clientId: "agente-ia" }),
    authTimeoutMs: 180000,
    puppeteer: { headless: true, timeout: 120000, args: ["--no-sandbox", "--disable-setuid-sandbox", "--disable-dev-shm-usage", "--disable-gpu"] },
  });

  whatsappClient.on("qr", async (qr) => { try { const d = await QRCode.toDataURL(qr, { width: 300 }); io.emit("qr", d); io.emit("status", { conectado: false, mensagem: "Escaneie o QR Code" }); } catch (e) {} });
  whatsappClient.on("ready", () => { whatsappConectado = true; io.emit("qr", null); io.emit("status", { conectado: true, mensagem: "Conectado!" }); console.log("Conectado!"); });
  whatsappClient.on("disconnected", () => { whatsappConectado = false; io.emit("status", { conectado: false, mensagem: "Desconectado" }); });

  // Detectar intervenção humana
  whatsappClient.on("message_create", async (msg) => {
    if (!msg.fromMe) return;
    const tel = msg.to;
    if (tel.includes("@g.us") || tel.includes("broadcast")) return;
    
    const txt = (msg.body || "").trim().toLowerCase();
    
    if (txt === "!bot on") { clientesPausados.delete(tel); await whatsappClient.sendMessage(tel, "Bot reativado."); return; }
    if (txt === "!bot off") { clientesPausados.set(tel, { pausado: true }); await whatsappClient.sendMessage(tel, "Bot pausado."); return; }
    if (txt === "!bot status") { await whatsappClient.sendMessage(tel, `Status: ${clientesPausados.has(tel) ? "PAUSADO" : "ATIVO"}`); return; }

    const ult = mensagensEnviadasPeloBot.get(tel) || 0;
    if (Date.now() - ult < 2000) return;
    
    if (!clientesPausados.has(tel)) {
      clientesPausados.set(tel, { pausado: true, motivo: "humano" });
      console.log(`[PAUSADO] Humano entrou: ${tel}`);
    }
  });

  whatsappClient.on("message", handleMessage);
  whatsappClient.initialize().catch((err) => console.error("Erro:", err));
}

// =====================================
// LOGICA DE MENSAGENS
// =====================================
const delay = (ms) => new Promise(r => setTimeout(r, ms));

async function handleMessage(msg) {
  try {
    const from = msg.from || "";
    if (from.includes("status") || from.includes("broadcast") || from.includes("@g.us")) return;
    const chat = await msg.getChat();
    if (chat.isGroup) return;
    if (msg.timestamp && (Date.now() / 1000 - msg.timestamp) > 300) return;

    const texto = msg.body?.trim() || "";
    if (!texto) return;
    const textoLower = texto.toLowerCase();

    // Verificar se é número favorito (bot ignora)
    const numeroLimpo = from.replace(/[@\.]/g, "").slice(0, 15);
    if (numerosFavoritos.some(n => {
      const nLimpo = n.replace(/[@\.]/g, "").slice(0, 15);
      return numeroLimpo.includes(nLimpo) || nLimpo.includes(numeroLimpo);
    })) {
      console.log(`⭐ Número favorito, ignorando: ${from}`);
      return;
    }

    // Verificar pausa
    if (clientesPausados.has(from)) {
      if (textoLower === "bot" || textoLower === "menu") {
        clientesPausados.delete(from);
        console.log(`[REATIVADO] ${from}`);
      } else {
        console.log(`[SILENCIOSO] ${from}: ${texto.substring(0, 30)}`);
        return;
      }
    }

    adicionarHistorico(from, "cliente", texto);
    await delay(400);
    await chat.sendStateTyping();
    await delay(600);

    // Saudação
    if (["oi", "ola", "olá", "hey", "bom dia", "boa tarde", "boa noite", "menu", "bot"].some(s => textoLower === s || textoLower.startsWith(s + " "))) {
      let s = sessoesAtendimento.get(from);
      if (!s) { s = { protocolo: gerarProtocolo() }; sessoesAtendimento.set(from, s); }
      mensagensEnviadasPeloBot.set(from, Date.now());
      await msg.reply(getMenuTexto(s.protocolo));
      return;
    }

    // Atendente
    if (textoLower.includes("atendente") || textoLower.includes("humano") || textoLower.includes("falar com")) {
      clientesPausados.set(from, { pausado: true, motivo: "cliente" });
      const s = sessoesAtendimento.get(from);
      mensagensEnviadasPeloBot.set(from, Date.now());
      await msg.reply(`Transferindo para atendente!\n\nProtocolo: ${s?.protocolo || gerarProtocolo()}\n\nAguarde.\n\nDigite "bot" para reativar.`);
      console.log(`[PAUSADO] Cliente pediu atendente: ${from}`);
      return;
    }

    // Menu numérico
    const num = parseInt(texto);
    if (!isNaN(num) && num >= 1 && num <= 7) {
      const cats = baseConhecimento?.categorias || {};
      const respostas = {
        1: cats.servicos?.respostaPadrao || "Servicos: celulares, notebooks, tablets, videogames",
        2: cats.horarios?.respostaPadrao || "Seg-Sex 8:30-17:30, Sab 8:00-12:00",
        3: cats.valores?.respostaPadrao || "Orcamento gratuito!",
        4: cats.localizacao?.respostaPadrao || "Consulte endereco",
        5: cats.pagamento?.respostaPadrao || "Dinheiro, PIX, Cartao",
        6: cats.garantia?.respostaPadrao || "90 dias"
      };
      if (num === 7) {
        clientesPausados.set(from, { pausado: true, motivo: "menu" });
        const s = sessoesAtendimento.get(from);
        mensagensEnviadasPeloBot.set(from, Date.now());
        await msg.reply(`Transferindo para atendente!\n\nProtocolo: ${s?.protocolo || gerarProtocolo()}\n\nAguarde.\n\nDigite "bot" para reativar.`);
        return;
      }
      mensagensEnviadasPeloBot.set(from, Date.now());
      await msg.reply(respostas[num]);
      return;
    }

    // PRIMEIRO: Buscar na base de conhecimento
    const respostaBase = buscarNaBase(texto);
    if (respostaBase) {
      console.log(`[BASE] ${from}: ${texto.substring(0, 30)}`);
      mensagensEnviadasPeloBot.set(from, Date.now());
      await msg.reply(respostaBase);
      return;
    }

    // SEGUNDO: Usar IA (com regras rigidas)
    if (config.useAI && groqClient) {
      const resposta = await respostaPorIA(texto, from);
      if (resposta) {
        console.log(`[IA] ${from}: ${texto.substring(0, 30)}`);
        mensagensEnviadasPeloBot.set(from, Date.now());
        await msg.reply(resposta);
        return;
      }
    }

    // FALLBACK
    mensagensEnviadasPeloBot.set(from, Date.now());
    await msg.reply("Nao tenho essa informacao.\n\nDigite *menu* para ver as opcoes ou *atendente* para falar com uma pessoa.");

  } catch (error) {
    console.error("Erro:", error.message);
  }
}

// =====================================
// SOCKET
// =====================================
io.on("connection", (socket) => {
  socket.emit("status", { conectado: whatsappConectado });
  if (!whatsappConectado) socket.emit("qr", "loading");
  const l = []; clientesPausados.forEach((v, k) => l.push({ telefone: k, ...v }));
  socket.emit("clientes-pausados", l);
});

// =====================================
// INICIAR
// =====================================
server.listen(PORT, () => {
  console.log(`
==============================================
  BOT WHATSAPP v7.5 - FAVORITOS
==============================================
  Painel: http://localhost:${PORT}
  
  - IA so usa dados cadastrados
  - NUNCA inventa valores
  - Auto-pausa quando voce responde
  - FAVORITOS: bot ignora permanentemente
==============================================
  `);
  io.emit("qr", "loading");
  initWhatsApp();
});
